import { MongoClient, ObjectId } from "mongodb";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const headers={"Content-Type":"application/json; charset=utf-8","Access-Control-Allow-Origin":process.env.ALLOWED_ORIGIN||"*","Access-Control-Allow-Headers":"Content-Type, Authorization","Access-Control-Allow-Methods":"GET, POST, PATCH, OPTIONS","Cache-Control":"no-store"};
const reply=(statusCode,data)=>({statusCode,headers,body:JSON.stringify(data)});
const bad=(message,statusCode=400)=>reply(statusCode,{error:message});
const iso=()=>new Date().toISOString();
const id=v=>ObjectId.isValid(String(v))?new ObjectId(String(v)):null;
let clientPromise;
async function db(){
 if(!process.env.MONGODB_URI)throw new Error("Database not configured. Add MONGODB_URI in Netlify environment variables.");
 if(!clientPromise)clientPromise=new MongoClient(process.env.MONGODB_URI,{serverSelectionTimeoutMS:8000}).connect();
 const client=await clientPromise;return client.db(process.env.MONGODB_DB||"kala_setu");
}
const homesSeed=[
 {name:"Saanjh Creative Home",city:"Jaipur, Rajasthan",story:"Fictional community celebrating painting and craft.",focus:"Painting & craft",icon:"🌅",verified:true},
 {name:"Udaan Senior Living",city:"Agra, Uttar Pradesh",story:"Synthetic profile highlighting textile traditions.",focus:"Textile & embroidery",icon:"🪷",verified:true},
 {name:"Aarambh Care Collective",city:"Pune, Maharashtra",story:"Illustrative community exploring pottery and nature-inspired art.",focus:"Pottery & sculpture",icon:"🌿",verified:true},
 {name:"Mitti & Memories Home",city:"Bhopal, Madhya Pradesh",story:"Fictional creative programme focused on clay and mixed media.",focus:"Clay & mixed media",icon:"🏺",verified:false},
 {name:"Nayi Disha Community",city:"Lucknow, Uttar Pradesh",story:"Sample community sharing handmade pieces and stories.",focus:"Craft & textile",icon:"🧵",verified:false}
];
const artSeed=[
 ["Evening by the River","Painting","Acrylic on canvas",1200,"Saanjh Creative Home","🌄","#ead6bd",["landscape","warm","sunset"]],
 ["Terracotta Sunrise Vase","Pottery","Hand-shaped clay",850,"Aarambh Care Collective","🏺","#e6c9b3",["pottery","earth","vase"]],
 ["Marigold Garden","Painting","Watercolour on paper",950,"Saanjh Creative Home","🌼","#f2df9f",["floral","yellow","garden"]],
 ["Indigo Morning Scarf","Textile","Cotton embroidery",1450,"Udaan Senior Living","🧣","#c7d7e2",["textile","blue","embroidery"]],
 ["Little Forest Sculpture","Sculpture","Recycled mixed media",1750,"Mitti & Memories Home","🌳","#cbd9c1",["nature","green","sculpture"]],
 ["Lotus at Dusk","Painting","Acrylic on canvas",1350,"Nayi Disha Community","🪷","#ead1d9",["floral","pink","lotus"]],
 ["Handwoven Table Runner","Textile","Cotton weave",1100,"Udaan Senior Living","🧶","#e7d9bd",["textile","earth","woven"]],
 ["Blue Pottery Keepsake","Pottery","Glazed ceramic",980,"Aarambh Care Collective","🫖","#c9e0e4",["pottery","blue","ceramic"]],
 ["Sunbird Paper Craft","Craft","Layered handmade paper",650,"Nayi Disha Community","🐦","#f0d4a9",["paper","bird","yellow"]],
 ["Quiet Hills","Painting","Acrylic on canvas",1600,"Mitti & Memories Home","⛰️","#d4dfcf",["landscape","green","hills"]],
 ["Embroidered Bloom Hoop","Textile","Thread embroidery",750,"Udaan Senior Living","🪡","#f0d7cf",["textile","pink","embroidery"]],
 ["Little Clay Bird","Sculpture","Air-dry clay",550,"Saanjh Creative Home","🕊️","#e9d8bf",["clay","bird","earth"]]
];
async function seed(d){
 await Promise.all([d.users.createIndex({email:1},{unique:true}),d.orders.createIndex({userId:1,createdAt:-1}),d.donations.createIndex({userId:1,createdAt:-1})]);
 if(!await d.homes.countDocuments()){await d.homes.insertMany(homesSeed.map(h=>({...h,demo:true,createdAt:iso()})));}
 if(!await d.artworks.countDocuments()){
  const hs=await d.homes.find().toArray();
  await d.artworks.insertMany(artSeed.map((a,i)=>({title:a[0],category:a[1],medium:a[2],price:a[3],homeName:a[4],homeId:hs.find(h=>h.name===a[4])?._id,emoji:a[5],bg:a[6],tags:a[7],description:"Fictional synthetic demo artwork.",status:i===4?"pending":"available",featured:i<4,demo:true,createdAt:iso(),updatedAt:iso()})));
 }
 if(!await d.reviews.countDocuments())await d.reviews.insertMany([
  {title:"Patterned Clay Bowl",homeName:"Saanjh Creative Home",status:"pending",createdAt:iso()},
  {title:"Autumn Tree Study",homeName:"Mitti & Memories Home",status:"pending",createdAt:iso()},
  {title:"Soft Cotton Wall Hanging",homeName:"Udaan Senior Living",status:"pending",createdAt:iso()}]);
 if(!await d.flags.countDocuments())await d.flags.insertMany([
  {reference:"TX-DEMO-104",pattern:"Repeated small contributions from a synthetic card",score:.82,status:"review",demo:true},
  {reference:"TX-DEMO-118",pattern:"Unusual order frequency from a synthetic IP",score:.71,status:"review",demo:true}]);
}
function bodyOf(e){try{return JSON.parse(e.body||"{}")}catch{return null}}
function tokenOf(e){const h=e.headers?.authorization||e.headers?.Authorization||"";return h.startsWith("Bearer ")?h.slice(7):null}
async function userOf(e,d,roles=[]){
 if(!process.env.JWT_SECRET)throw Object.assign(new Error("JWT_SECRET is not configured."),{status:503});
 const t=tokenOf(e);if(!t)throw Object.assign(new Error("Sign in required."),{status:401});
 let p;try{p=jwt.verify(t,process.env.JWT_SECRET)}catch{throw Object.assign(new Error("Session expired. Sign in again."),{status:401})}
 const u=await d.collection("users").findOne({_id:id(p.sub)});if(!u)throw Object.assign(new Error("Account not found."),{status:401});
 if(roles.length&&!roles.includes(u.role))throw Object.assign(new Error("Insufficient permission."),{status:403});return u;
}
const safeUser=u=>({_id:String(u._id),name:u.name,email:u.email,role:u.role,createdAt:u.createdAt});
const safeArt=a=>({...a,_id:String(a._id),homeId:a.homeId?String(a.homeId):null});
export async function handler(e){
 if(e.httpMethod==="OPTIONS")return{statusCode:204,headers,body:""};
 const path=(e.path||"").replace(/^\/\.netlify\/functions\/api/,"").replace(/^\/api/,"").replace(/\/+$/,"")||"/",method=e.httpMethod,b=bodyOf(e);
 if(path==="/health"&&method==="GET")return reply(200,{ok:true,service:"Kala-Setu API",databaseConfigured:Boolean(process.env.MONGODB_URI),payments:"disabled",time:iso()});
 if(["POST","PATCH"].includes(method)&&b===null)return bad("Invalid JSON.");
 let d;try{d=await db();await seed(d)}catch(err){return reply(503,{error:"Persistent database unavailable.",help:"Configure MONGODB_URI, MONGODB_DB and JWT_SECRET in Netlify environment variables.",detail:process.env.NODE_ENV==="development"?err.message:undefined})}
 try{
  if(path==="/artworks"&&method==="GET"){
   const q=(e.queryStringParameters?.q||"").trim(),cat=e.queryStringParameters?.category,status=e.queryStringParameters?.status||"available",f={};
   if(status!=="all")f.status=status;if(cat)f.category=cat;if(q)f.$or=["title","category","medium","homeName"].map(k=>({[k]:{$regex:q.replace(/[.*+?^${}()|[\]\\]/g,"\\$&"),$options:"i"}}));
   const items=await d.collection("artworks").find(f).sort({featured:-1,createdAt:-1}).limit(100).toArray();return reply(200,{items:items.map(safeArt),count:items.length});
  }
  if(path.startsWith("/artworks/")&&method==="GET"){const x=id(path.split("/")[2]);if(!x)return bad("Invalid ID");const a=await d.collection("artworks").findOne({_id:x});return a?reply(200,{item:safeArt(a)}):bad("Not found",404)}
  if(path==="/homes"&&method==="GET"){const items=await d.collection("homes").find().sort({name:1}).toArray();return reply(200,{items:items.map(h=>({...h,_id:String(h._id)}))})}
  if(path==="/auth/register"&&method==="POST"){
   if(!b.name?.trim()||!b.email?.trim()||String(b.password||"").length<8)return bad("Name, valid email and password (8+ characters) required.");
   if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(b.email))return bad("Invalid email.");
   const email=b.email.trim().toLowerCase();if(await d.collection("users").findOne({email}))return bad("Email already registered.",409);
   const u={name:b.name.trim().slice(0,100),email,passwordHash:await bcrypt.hash(b.password,12),role:"buyer",createdAt:iso()};
   const r=await d.collection("users").insertOne(u);u._id=r.insertedId;const token=jwt.sign({sub:String(u._id)},process.env.JWT_SECRET,{expiresIn:"7d"});return reply(201,{token,user:safeUser(u)});
  }
  if(path==="/auth/login"&&method==="POST"){
   const u=await d.collection("users").findOne({email:String(b.email||"").trim().toLowerCase()});if(!u||!await bcrypt.compare(String(b.password||""),u.passwordHash))return bad("Email or password incorrect.",401);
   const token=jwt.sign({sub:String(u._id)},process.env.JWT_SECRET,{expiresIn:"7d"});return reply(200,{token,user:safeUser(u)});
  }
  if(path==="/auth/me"&&method==="GET"){const u=await userOf(e,d);return reply(200,{user:safeUser(u)})}
  if(path==="/artworks"&&method==="POST"){
   const u=await userOf(e,d,["coordinator","admin"]);for(const k of ["title","category","medium","homeName"])if(typeof b[k]!=="string"||!b[k].trim())return bad("Missing "+k);
   const price=Number(b.price);if(!Number.isFinite(price)||price<1)return bad("Invalid price");
   const h=await d.collection("homes").findOne({name:b.homeName});if(!h)return bad("Home not found");
   const doc={title:b.title.trim().slice(0,160),category:b.category,medium:b.medium.trim().slice(0,160),price,homeName:h.name,homeId:h._id,description:String(b.description||"Demo listing").slice(0,1500),tags:Array.isArray(b.tags)?b.tags.slice(0,12):[],emoji:String(b.emoji||"🎨").slice(0,8),bg:"#e9d8bf",status:"pending",featured:false,createdAt:iso(),updatedAt:iso(),createdBy:u._id,demo:true};
   const r=await d.collection("artworks").insertOne(doc);return reply(201,{item:safeArt({...doc,_id:r.insertedId}),message:"Submitted for admin review."});
  }
  if(path.startsWith("/artworks/")&&method==="PATCH"){
   await userOf(e,d,["coordinator","admin"]);const x=id(path.split("/")[2]);if(!x)return bad("Invalid ID");
   const upd={};for(const k of ["title","category","medium","description","status","price","tags"])if(b[k]!==undefined)upd[k]=b[k];
   if(upd.price!==undefined&&(!Number.isFinite(Number(upd.price))||Number(upd.price)<1))return bad("Invalid price");if(upd.price!==undefined)upd.price=Number(upd.price);
   if(upd.status&&!["pending","available","sold","archived"].includes(upd.status))return bad("Invalid status");upd.updatedAt=iso();
   const r=await d.collection("artworks").updateOne({_id:x},{$set:upd});if(!r.matchedCount)return bad("Not found",404);return reply(200,{item:safeArt(await d.collection("artworks").findOne({_id:x}))});
  }
  if(path==="/orders"&&method==="GET"){const u=await userOf(e,d);const items=await d.collection("orders").find({userId:u._id}).sort({createdAt:-1}).limit(100).toArray();return reply(200,{items:items.map(x=>({...x,_id:String(x._id),userId:String(x.userId)}))})}
  if(path==="/orders"&&method==="POST"){
   const u=await userOf(e,d),ids=Array.isArray(b.artworkIds)?b.artworkIds.slice(0,30):[];if(!ids.length)return bad("Provide artworkIds");
   const objectIds=ids.map(id);if(objectIds.some(x=>!x)||new Set(ids.map(String)).size!==ids.length)return bad("Invalid/duplicate artwork IDs");
   const items=await d.collection("artworks").find({_id:{$in:objectIds},status:"available"}).toArray();if(items.length!==ids.length)return bad("An artwork is unavailable; refresh your bag.",409);
   const order={reference:"KS-DEMO-"+Date.now().toString().slice(-8),userId:u._id,items:items.map(a=>({artworkId:a._id,title:a.title,price:a.price,homeName:a.homeName})),total:items.reduce((s,a)=>s+a.price,0),status:"simulated-confirmed",paymentStatus:"not-charged",createdAt:iso(),demo:true};
   // Conditional updates stop two buyers from buying the same one-off item at once.
   const changed=[];for(const a of items){const r=await d.collection("artworks").updateOne({_id:a._id,status:"available"},{$set:{status:"sold",updatedAt:iso()}});if(!r.modifiedCount){if(changed.length)await d.collection("artworks").updateMany({_id:{$in:changed},status:"sold"},{$set:{status:"available"}});return bad("An artwork was just sold; refresh the bag.",409)}changed.push(a._id)}
   const r=await d.collection("orders").insertOne(order);return reply(201,{order:{...order,_id:String(r.insertedId)},message:"Simulated order; no payment taken."});
  }
  if(path==="/donations"&&method==="GET"){const u=await userOf(e,d);const items=await d.collection("donations").find({userId:u._id}).sort({createdAt:-1}).limit(100).toArray();return reply(200,{items:items.map(x=>({...x,_id:String(x._id),userId:String(x.userId),homeId:String(x.homeId)}))})}
  if(path==="/donations"&&method==="POST"){
   const u=await userOf(e,d),hid=id(b.homeId),amount=Number(b.amount);if(!hid||!Number.isFinite(amount)||amount<1||amount>1000000)return bad("Valid homeId and amount required");
   const h=await d.collection("homes").findOne({_id:hid});if(!h)return bad("Home not found");
   const doc={userId:u._id,homeId:h._id,homeName:h.name,amount,status:"simulated",paymentStatus:"not-charged",createdAt:iso(),demo:true};const r=await d.collection("donations").insertOne(doc);return reply(201,{donation:{...doc,_id:String(r.insertedId)},message:"Simulated donation; no money collected."});
  }
  if(path==="/admin/reviews"&&method==="GET"){await userOf(e,d,["admin"]);const [reviews,homes]=await Promise.all([d.collection("reviews").find().toArray(),d.collection("homes").find({verified:false}).toArray()]);return reply(200,{reviews:reviews.map(x=>({...x,_id:String(x._id)})),homes:homes.map(x=>({...x,_id:String(x._id)}))})}
  if(path.startsWith("/admin/reviews/")&&method==="PATCH"){await userOf(e,d,["admin"]);const x=id(path.split("/")[3]);if(!x||!["approved","needs-changes","rejected"].includes(b.status))return bad("Invalid review/status");const r=await d.collection("reviews").updateOne({_id:x},{$set:{status:b.status,reviewedAt:iso()}});return r.matchedCount?reply(200,{message:"Review updated"}):bad("Not found",404)}
  if(path.startsWith("/admin/homes/")&&method==="PATCH"){await userOf(e,d,["admin"]);const x=id(path.split("/")[3]);if(!x)return bad("Invalid ID");const r=await d.collection("homes").updateOne({_id:x},{$set:{verified:Boolean(b.verified),updatedAt:iso()}});return r.matchedCount?reply(200,{message:"Home verification updated"}):bad("Not found",404)}
  if(path==="/admin/flags"&&method==="GET"){await userOf(e,d,["admin"]);const items=await d.collection("flags").find().toArray();return reply(200,{items:items.map(x=>({...x,_id:String(x._id)}))})}
  if(path.startsWith("/admin/flags/")&&method==="PATCH"){await userOf(e,d,["admin"]);const x=id(path.split("/")[3]);if(!x)return bad("Invalid ID");const r=await d.collection("flags").updateOne({_id:x},{$set:{status:"reviewed",reviewedAt:iso(),reviewNote:String(b.note||"Reviewed").slice(0,500)}});return r.matchedCount?reply(200,{message:"Flag reviewed"}):bad("Not found",404)}
  if(path==="/ml/tag-suggest"&&method==="POST"){
   const text=[b.title,b.description,b.medium].filter(Boolean).join(" ").toLowerCase();if(!text)return bad("Provide artwork details");
   const rules=[["Painting",/paint|canvas|watercolou?r|landscape|acrylic/],["Pottery",/pot|clay|ceramic|vase|terracotta/],["Textile",/textile|embroider|weav|cotton|scarf|fabric|thread/],["Sculpture",/sculpt|statue|carv|3d/],["Craft",/paper|craft|handmade|mixed media/]];
   const category=rules.find(x=>x[1].test(text))?.[0]||"Craft",tags=[...new Set(text.match(/landscape|floral|blue|green|earth|sunset|cotton|clay|ceramic|embroidery|nature|abstract|traditional|modern|handmade/g)||[])].slice(0,8);
   return reply(200,{category,tags,method:"rule-based demo",notice:"Not a trained image model; coordinator must confirm suggestions."});
  }
  if(path==="/ml/recommendations"&&method==="GET"){const x=id(e.queryStringParameters?.artworkId);if(!x)return bad("artworkId required");const a=await d.collection("artworks").findOne({_id:x});if(!a)return bad("Artwork not found",404);const pool=await d.collection("artworks").find({status:"available",_id:{$ne:x}}).limit(100).toArray();const score=p=>(p.category===a.category?3:0)+(p.medium===a.medium?2:0)+(p.homeName===a.homeName?1:0)+((p.tags||[]).filter(t=>(a.tags||[]).includes(t)).length*1.5)-Math.abs(p.price-a.price)/Math.max(a.price,1);pool.sort((x,y)=>score(y)-score(x));return reply(200,{items:pool.slice(0,6).map(safeArt),method:"metadata similarity",notice:"Demo baseline; not trained on buyer history."})}
  if(path==="/ml/anomaly-score"&&method==="POST"){await userOf(e,d,["admin"]);let score=0,reasons=[];if(Number(b.amount)>10000){score+=.35;reasons.push("Unusually high amount for demo threshold")}if(Number(b.recentTransactions)>8){score+=.4;reasons.push("High recent transaction frequency")}if(b.repeatedSmallAmounts){score+=.25;reasons.push("Repeated small-amount pattern")}return reply(200,{score:Math.min(score,1),flag:score>=.5,reasons,notice:"Heuristic demonstration, not a trained fraud model."})}
  return bad("Route not found",404);
 }catch(err){return reply(err.status||500,{error:err.status?err.message:"Backend error",detail:process.env.NODE_ENV==="development"?err.message:undefined})}
}
