# Kala-Setu — Netlify-ready prototype

## What's included
- Responsive storefront and existing interactive demo pages.
- Netlify Functions API (`/.netlify/functions/api`) with `/api/*` rewrite.
- MongoDB persistence for artworks, homes, users, simulated orders/donations, moderation reviews and anomaly flags.
- Password hashing (bcrypt) and JWT-based sessions.
- Role-protected coordinator/admin endpoints.
- Rule-based artwork tag suggestions, metadata-similarity recommendations and transparent heuristic anomaly scoring.
- No real payment integration: checkout and donations are explicitly simulated.

## Deploy to Netlify
1. Download and extract this ZIP.
2. Create a GitHub repository and upload all extracted files (including `netlify/`, `public/`, `package.json`, and `netlify.toml`).
3. In Netlify choose **Add new site → Import an existing project** and select that repository.
4. Build command: `npm run build`; publish directory: `public`.
5. Create a MongoDB Atlas free cluster and database user. Copy its connection URI.
6. In Netlify → Site configuration → Environment variables, add:
   - `MONGODB_URI` = your Atlas URI
   - `MONGODB_DB` = `kala_setu`
   - `JWT_SECRET` = a long random secret (32+ characters)
7. Redeploy, then open `https://YOUR-SITE.netlify.app/api/health`. It should report `databaseConfigured: true`.
8. The first API request seeds fictional sample homes, artworks, moderation reviews and anomaly flags.
9. Register a normal account through the API/frontend. To grant coordinator/admin rights, change that user's `role` field in MongoDB Atlas to `coordinator` or `admin`. There is deliberately no public role escalation.

## Test endpoints
- `GET /api/health`
- `GET /api/artworks` and `GET /api/artworks/:id`
- `GET /api/homes`
- `POST /api/auth/register` with `{ "name":"Demo User", "email":"demo@example.com", "password":"a-long-password" }`
- `POST /api/auth/login`
- `GET /api/auth/me` (Bearer token)
- `POST /api/artworks` and `PATCH /api/artworks/:id` (coordinator/admin)
- `GET /api/orders`, `POST /api/orders` (authenticated; simulated only)
- `GET /api/donations`, `POST /api/donations` (authenticated; simulated only)
- `GET /api/admin/reviews`, `PATCH /api/admin/reviews/:id`
- `PATCH /api/admin/homes/:id`
- `GET /api/admin/flags`, `PATCH /api/admin/flags/:id`
- `POST /api/ml/tag-suggest`
- `GET /api/ml/recommendations?artworkId=...`
- `POST /api/ml/anomaly-score` (admin)

## Run locally (optional)
Install Node.js LTS, then run:
```bash
npm install
cp .env.example .env
npx netlify dev
```
On Windows PowerShell, use `Copy-Item .env.example .env`. Fill in `.env` with your own database URI and secret. Never commit `.env` or publish secrets.

## Honest limitations
- The existing front-end demo still runs in browser mode without credentials; its existing interactive demo state is local. The API bridge reports backend status and loads API data for inspection, but not every existing front-end action has been wired to persistent API endpoints yet. API endpoints themselves are provided and ready for integration.
- Without MongoDB variables, Netlify Functions cannot persist data and return a setup error; the static demo remains viewable.
- Tagging is rule-based; recommendations use metadata similarity; anomaly scoring is heuristic. These are demonstrations, not trained/validated ML models.
- No real payment, payout, shipping, tax, charitable receipt, or legal donation-compliance workflow is included.
- Before a real public launch, complete security testing, privacy/consent review, backups, accessibility checks, and applicable legal/compliance work.
